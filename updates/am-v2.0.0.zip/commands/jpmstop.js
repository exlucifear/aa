const { getJpmStatus, stopJpm } = require('../lib/jpmcontrol');
const { formatError, formatSuccess } = require('../lib/messageFormat');

async function jpmstop(sock, sender, messages, key, messageEvent) {
    if (!getJpmStatus().isRunning) {
        await sock.sendMessage(sender, { text: formatError('𝙹𝙿𝙼 SEDANG 𝚃𝙸𝙳𝙰𝙺 𝙱𝙴𝚁𝙹𝙰𝙻𝙰𝙽') });
        return;
    }

    stopJpm();
    await sock.sendMessage(sender, { text: formatSuccess('JPM TELAH DIHENTIKAN') });
}

module.exports = jpmstop; 