const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const fs = require('fs').promises;
const path = require('path');

async function listban(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        const bannedGroupsPath = path.join(__dirname, '../data/bannedGroups.json');
        let bannedGroups = [];
        
        try {
            const data = await fs.readFile(bannedGroupsPath, 'utf8');
            bannedGroups = JSON.parse(data);
        } catch (error) {
            const message = formatMessage('𝑳𝑰𝑺𝑻 𝑩𝑨𝑵', 'Tidak ada grup yang diban');
            return sock.sendMessage(sender, { text: message });
        }

        if (bannedGroups.length === 0) {
            const message = formatMessage('𝑳𝑰𝑺𝑻 𝑩𝑨𝑵', 'Tidak ada grup yang diban');
            return sock.sendMessage(sender, { text: message });
        }

        // Get group names
        const groupDetails = await Promise.all(
            bannedGroups.map(async (groupId) => {
                try {
                    const groupInfo = await sock.groupMetadata(groupId);
                    return {
                        id: groupId,
                        name: groupInfo.subject || 'Unknown Group'
                    };
                } catch (error) {
                    return {
                        id: groupId,
                        name: 'Unknown Group'
                    };
                }
            })
        );

        const message = formatMessage('𝑳𝑰𝑺𝑻 𝑩𝑨𝑵', 
            `Daftar grup yang diban:\n` +
            groupDetails.map((group, index) => 
                `${index + 1}. ${group.name}\n   ID: ${group.id}`
            ).join('\n')
        );
        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in listban:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil daftar grup yang diban');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = listban;
