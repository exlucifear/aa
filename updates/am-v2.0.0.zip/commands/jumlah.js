const fs = require('fs');
const path = require('path');
const clc = require('cli-color');
const { initializeGroup, getNewMemberCount, getAllGroupData, incrementMember } = require('../lib/jumlah');
const { formatMessage, formatError } = require('../lib/messageFormat');
const memberDataPath = path.join(__dirname, '../data/memberData.json');

function loadMemberData() {
  try {
    if (!fs.existsSync(memberDataPath)) return {};
    return JSON.parse(fs.readFileSync(memberDataPath));
  } catch (error) {
    console.error(clc.red('[JUMLAH] Gagal membaca memberData:'), error);
    return {};
  }
}

function saveMemberData(data) {
  try {
    fs.writeFileSync(memberDataPath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error(clc.red('[JUMLAH] Gagal menyimpan memberData:'), error);
  }
}

async function jumlah(sock, senderJid, body, messageKey, messageEvent, args, senderNumber) {
  try {
    let targetGroupId;

    // Check if command is used in private chat or group
    if (senderJid.endsWith('@s.whatsapp.net')) {
      // Private chat - need group ID as argument
      if (!args.length) {
        const errorMessage = formatError('ID grup harus diisi saat menggunakan command di private chat');
        return sock.sendMessage(senderJid, { text: errorMessage });
      }
      targetGroupId = args[0];
      if (!targetGroupId.endsWith('@g.us')) {
        const errorMessage = formatError('ID grup tidak valid');
        return sock.sendMessage(senderJid, { text: errorMessage });
      }
    } else {
      // Group chat - use current group ID
      targetGroupId = senderJid;
    }

    // Get group participants
    const groupInfo = await sock.groupMetadata(targetGroupId);
    const participants = groupInfo.participants.map(p => p.id);

    // Initialize group if not exists
    const memberData = loadMemberData();
    if (!memberData[targetGroupId]) {
      initializeGroup(targetGroupId, participants);
    }

    const result = await incrementMember(targetGroupId, sock);
    if (!result.success) {
      const errorMessage = formatError(result.error || 'Gagal memperbarui jumlah member');
      return sock.sendMessage(senderJid, { text: errorMessage });
    }

    const message = formatMessage('𝑱𝑼𝑴𝑳𝑨𝑯', 
      `Jumlah member: ${result.currentMembers}\n` +
      `Member baru: ${result.newMembers}\n` +
      `Target: ${result.target || 'Belum diset'}`
    );
    await sock.sendMessage(senderJid, { text: message });
  } catch (error) {
    console.error(clc.red('Error in jumlah:'), error);
    const errorMessage = formatError('Terjadi kesalahan saat memperbarui jumlah member');
    await sock.sendMessage(senderJid, { text: errorMessage });
  }
}

module.exports = jumlah;
