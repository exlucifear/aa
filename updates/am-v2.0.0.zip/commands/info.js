const clc = require('cli-color');
const os = require('os');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { getJpmStatus } = require('../lib/jpmcontrol');
const { getAllGroupData } = require('../lib/jumlah');
const { getBannedGroups } = require('../lib/jpmBanManager');

async function info(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        // Informasi Sistem
        const totalMemory = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
        const freeMemory = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
        const usedMemory = (totalMemory - freeMemory).toFixed(2);
        const uptime = formatUptime(os.uptime());
        const cpuModel = os.cpus()[0].model;
        const cpuCores = os.cpus().length;
        const platform = `${os.platform()} ${os.release()}`;
        const hostname = os.hostname();

        // Informasi Bot
        const jpmStatus = getJpmStatus();
        const groupData = getAllGroupData();
        const bannedGroups = getBannedGroups();
        
        // Hitung statistik
        const totalGroups = Object.keys(groupData).length;
        const totalBannedGroups = bannedGroups.length;
        const totalMembers = Object.values(groupData).reduce((sum, data) => sum + (data.currentCount || 0), 0);
        const totalNewMembers = Object.values(groupData).reduce((sum, data) => {
            const newMembers = (data.currentCount || 0) - (data.initialCount || 0);
            return sum + (newMembers > 0 ? newMembers : 0);
        }, 0);

        // Format pesan
        const message = formatMessage({
            type: "info",
            title: "🤖 BOT INFORMATION",
            content: [
                "📱 BOT STATUS",
                `• Status JPM: ${jpmStatus.isRunning ? '🟢 Running' : '🔴 Stopped'}`,
                `• Runtime: ${formatRunTime(Math.floor(jpmStatus.runTime / 1000))}`,
                `• Iteration: ${jpmStatus.iteration || 0}`,
                `• Group Delay: ${jpmStatus.groupDelay || 0}ms`,
                `• Repeat Delay: ${jpmStatus.repeatDelay || 0}ms`,
                "",
                "📊 STATISTICS",
                `• Total Groups: ${totalGroups}`,
                `• Banned Groups: ${totalBannedGroups}`,
                `• Total Members: ${totalMembers}`,
                `• New Members: ${totalNewMembers}`,
                "",
                "💻 SERVER INFORMATION",
                `• OS: ${platform}`,
                `• Hostname: ${hostname}`,
                `• CPU: ${cpuModel}`,
                `• CPU Cores: ${cpuCores}`,
                `• Total Memory: ${totalMemory} GB`,
                `• Used Memory: ${usedMemory} GB`,
                `• Free Memory: ${freeMemory} GB`,
                `• Uptime: ${uptime}`,
                "",
                "📝 VERSION INFORMATION",
                `• Node.js: ${process.version}`,
                `• Bot Version: 2.0.0`,
                `• Developer: Amerie`
            ],
            footer: "Bot by Amerie"
        });

        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in info:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil informasi');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

// Helper function untuk format uptime
function formatUptime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    const parts = [];
    if (days > 0) parts.push(`${days} hari`);
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (secs > 0) parts.push(`${secs} detik`);

    return parts.join(' ');
}

// Helper function untuk format runtime
function formatRunTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (secs > 0) parts.push(`${secs} detik`);

    return parts.join(' ');
}

module.exports = info; 