const fs = require('fs');
const path = require('path');
const { displayTime } = require('../lib/utils');
const configPath = path.join(__dirname, '../data/jpm-config.json');
const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function jpmdelay(sock, sender, body, key, messageEvent, args, senderNumber) {
  if (typeof body !== 'string' || !body.trim()) {
    return sock.sendMessage(sender, {
      text: '❌ Tolong sertakan parameter delay.\nFormat: .delay [groupDelayDetik] [repeatDelayMenit]'
    });
  }

  const parts = body.trim().split(' ');

  if (parts.length !== 3) {
    return sock.sendMessage(sender, {
      text: '❌ Usage: .delay [groupDelayDetik] [repeatDelayMenit]'
    });
  }

  const groupDelayDetik = parseInt(parts[1]);
  const repeatDelayMenit = parseInt(parts[2]);

  if (isNaN(groupDelayDetik) || isNaN(repeatDelayMenit)) {
    return sock.sendMessage(sender, {
      text: '❌ Masukkan angka yang valid untuk delay.'
    });
  }

  const groupDelay = groupDelayDetik * 1000; // convert to ms
  const repeatDelay = repeatDelayMenit * 60 * 1000; // convert to ms

  global.jpmConfig = global.jpmConfig || {};
  global.jpmConfig.groupDelay = groupDelay;
  global.jpmConfig.repeatDelay = repeatDelay;

  try {
    fs.writeFileSync(configPath, JSON.stringify({
      groupDelay,
      repeatDelay
    }, null, 2));

    return sock.sendMessage(sender, {
      text: `✅ Delay berhasil diset:\n• Group delay: ${groupDelayDetik}s\n• Repeat delay: ${repeatDelayMenit}m\n\nDelay akan berlaku untuk putaran selanjutnya.`
    });
  } catch (err) {
    console.error("Gagal menyimpan jpm-config.json:", err);
    return sock.sendMessage(sender, { text: '❌ Gagal menyimpan konfigurasi delay.' });
  }
}

async function delay(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        if (!args.length) {
            const currentDelay = global.jpmConfig?.repeatDelay ? Math.floor(global.jpmConfig.repeatDelay / 60000) : 10;
            const message = formatMessage('𝑫𝑬𝑳𝑨𝒀', `Delay saat ini: ${currentDelay} menit`);
            return sock.sendMessage(sender, { text: message });
        }

        const newDelay = parseInt(args[0]);
        if (isNaN(newDelay) || newDelay < 1) {
            const errorMessage = formatError('Delay harus berupa angka positif');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        global.jpmConfig.repeatDelay = newDelay * 60000; // Convert to milliseconds
        const message = formatMessage('𝑫𝑬𝑳𝑨𝒀', `Delay berhasil diubah menjadi ${newDelay} menit`);
        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in delay:'), error);
        const errorMessage = formatError('Gagal mengubah delay');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = jpmdelay;
