const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { getAllGroupData } = require('../lib/jumlah');

async function listjumlah(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        const groupData = getAllGroupData();
        
        if (Object.keys(groupData).length === 0) {
            const message = formatMessage('𝑳𝑰𝑺𝑻 𝑱𝑼𝑴𝑳𝑨𝑯', 'Tidak ada data grup yang tersimpan');
            return sock.sendMessage(sender, { text: message });
        }

        // Format pesan untuk setiap grup
        const groupList = await Promise.all(Object.entries(groupData).map(async ([groupId, data], index) => {
            const initialCount = data.initialCount || 0;
            const currentCount = data.currentCount || 0;
            const newMembers = currentCount - initialCount;
            
            // Get group name
            let groupName = 'Unknown Group';
            try {
                const groupInfo = await sock.groupMetadata(groupId);
                groupName = groupInfo.subject || 'Unknown Group';
            } catch (error) {
                console.error(clc.yellow(`[LISTJUMLAH] Gagal mendapatkan nama grup ${groupId}:`), error);
            }
            
            return `${index + 1}. ${groupName}\n` +
                   `   ID: ${groupId}\n` +
                   `   Jumlah Awal: ${initialCount}\n` +
                   `   Jumlah Saat Ini: ${currentCount}\n` +
                   `   Member Baru: ${newMembers}`;
        }));

        const message = formatMessage('𝑳𝑰𝑺𝑻 𝑱𝑼𝑴𝑳𝑨𝑯', 
            `Total Grup: ${Object.keys(groupData).length}\n\n` +
            groupList.join('\n\n')
        );

        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in listjumlah:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil data jumlah member');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = listjumlah; 