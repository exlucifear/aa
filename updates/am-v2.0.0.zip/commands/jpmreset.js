const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { resetAllGroupData } = require('../lib/jumlah');
const { removeAllBannedGroups } = require('../lib/jpmBanManager');
const { stopJpm } = require('../lib/jpmcontrol');

async function jpmreset(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        // Hentikan JPM jika sedang berjalan
        stopJpm();

        // Reset semua data jumlah
        const resetResult = resetAllGroupData();
        if (!resetResult.success) {
            const errorMessage = formatError(resetResult.error || 'Gagal mereset data jumlah');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        // Unban semua grup
        const unbanResult = removeAllBannedGroups();
        if (!unbanResult.success) {
            const errorMessage = formatError(unbanResult.error || 'Gagal menghapus daftar ban grup');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        // Reset target dan groupId di global config
        if (global.jpmConfig) {
            global.jpmConfig.stopOnTarget = 0;
            global.jpmConfig.groupId = null;
        }

        const message = formatMessage({
            type: "success",
            title: "JPM RESET",
            content: [
                "Semua data JPM telah direset:",
                `- ${resetResult.totalGroups} data jumlah grup dihapus`,
                `- ${unbanResult.totalUnbanned} grup di-unban`,
                "Target dan status JPM telah direset"
            ],
            footer: "Bot by Amerie"
        });

        await sock.sendMessage(sender, { text: message });
        console.log(clc.green('[JPM] Semua data JPM berhasil direset'));

    } catch (error) {
        console.error(clc.red('Error in jpmreset:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mereset data JPM');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = jpmreset; 