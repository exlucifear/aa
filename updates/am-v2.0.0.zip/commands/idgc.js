const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function idgc(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        if (!sender.endsWith('@g.us')) {
            const errorMessage = formatError('Command ini hanya bisa digunakan di grup');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        const metadata = await sock.groupMetadata(sender);
        const message = formatMessage('𝑰𝑫 𝑮𝑹𝑼𝑷', 
            `Nama grup: ${metadata.subject}\n` +
            `ID grup: ${metadata.id}\n` +
            `Jumlah member: ${metadata.participants.length}`
        );
        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in idgc:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil informasi grup');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = idgc;
