const clc = require('cli-color');
const { formatHelp, formatError } = require('../lib/messageFormat');

async function help(sock, sender, body, key, messageEvent, args, senderNumber) {
    // Jika tidak ada argumen, tampilkan cara penggunaan help
    if (!args.length) {
        const helpText = formatHelp('HELP', {
            command: '.help [command]',
            function: ['Menampilkan detail penggunaan command'],
            example: ['.help jpm', '.help jpmtarget']
        });
        return sock.sendMessage(sender, { text: helpText });
    }

    const command = args[0].toLowerCase();
    const commandDetails = {
        jpm: {
            command: '.jpm [pesan]',
            function: [
                'Mengirim pesan ke semua grup',
                'Bisa mengirim teks dan gambar',
            ],
            example: [
                '.jpm halo semua',
                '.jpm [gambar] halo semua'
            ]
        },
        jpmconfig: {
            command: '.jpmconfig',
            function: [
                'Menampilkan konfigurasi JPM',
                'Menampilkan target, delay, dan grup yang diban'
            ]
        },
        jpmtarget: {
            command: '.jpmtarget [idgrup] [target]',
            function: [
                'grup otomatis masuk ke daftar ban',
                'mengatur target jumlah member baru untuk grup',
                'JPM akan berhenti otomatis jika target tercapai'
            ],
            example: [
                '.jpmtarget 100 (dari grup)',
                '.jpmtarget 1234567890@g.us 100 (dari private)'
            ]
        },
        jpmstop: {
            command: '.jpmstop',
            function: ['Menghentikan proses JPM yang sedang berjalan']
        },
        jpmstatus: {
            command: '.jpmstatus',
            function: [
                'Mengecek status JPM saat ini',
                'Menampilkan informasi delay dan iterasi'
            ]
        },
        jpmban: {
            command: '.jpmban [idgrup]',
            function: [
                'Menambahkan grup ke daftar ban JPM',
                'Grup yang diban tidak akan menerima pesan JPM',
                'Note: bisa gunakan .jpmtarget jika ingin langsung digunakan untuk JPM'
            ],
            example: ['.jpmban 1234567890@g.us']
        },
        jpmunban: {
            command: '.jpmunban [idgrup]',
            function: [
                'Menghapus grup dari daftar ban JPM',
                'Grup akan kembali menerima pesan JPM'
            ],
            example: ['.jpmunban 1234567890@g.us']
        },
        listban: {
            command: '.listban',
            function: ['Menampilkan daftar grup yang diban dari JPM']
        },
        calc: {
            command: '.calc',
            function: [
                'Kalkulator',
                'Bisa menggunakan operator +, -, *, /'
            ]
        },
        delay: {
            command: '.delay [detik] [menit]',
            function: [
                'Mengatur delay antar pesan JPM',
                'argumen detik untuk mengatur delay antar grup',
                'argumen menit untuk mengatur delay putaran',
                'note: jangan terlalu cepat, karena akan mudah terblokir'
            ],
            example: [
                '.delay 5 10',
                'mengatur delay antar grup setiap 5 detik dan pengulangan setiap 10 menit'
            ]
        },
        jumlah: {
            command: '.jumlah [idgrup]',
            function: [
                'Cek jumlah member grup',
                'Tampilkan jumlah awal dan member baru',
                'Note: bisa gunakan .jpmtarget jika ingin langsung digunakan untuk JPM'
            ],
            example: [
                '.jumlah (dari grup)',
                '.jumlah 1234567890@g.us (dari private)'
            ]
        },
        jumlahreset: {
            command: '.jumlahreset [idgrup]',
            function: [
                'Reset data jumlah member grup',
                'Menghapus data awal dan member baru'
            ],
            example: [
                '.jumlahreset (dari grup)',
                '.jumlahreset 1234567890@g.us (dari private)'
            ]
        },
        pushkontak: {
            command: '.pushkontak [idgrup] [pesan]',
            function: [
                'Kirim pesan ke semua kontak di grup',
                'Pesan dikirim ke nomor pribadi member'
            ],
            example: ['.pushkontak 1234567890@g.us halo semua']
        },
        listgc: {
            command: '.listgc',
            function: [
                'Menampilkan daftar grup yang tersedia',
                'Menampilkan ID dan nama grup'
            ]
        },
        idgc: {
            command: '.idgc',
            function: [
                'Mendapatkan ID grup saat ini',
                'Gunakan di dalam grup',
                'Berguna untuk command yang membutuhkan ID grup'
            ]
        },
        info: {
            command: '.info',
            function: [
                'Menampilkan informasi bot',
                'Menampilkan versi bot dan versi Node.js'
            ]
        },
        jpmreset: {
            command: '.jpmreset',
            function: [
                'Akan menghentikan proses JPM yang sedang berjalan',
                'Reset data JPM',
                'Menghapus data JPM yang ada'
            ]
        }
    };

    if (commandDetails[command]) {
        const helpText = formatHelp(command, commandDetails[command]);
        await sock.sendMessage(sender, { text: helpText });
    } else {
        const errorText = formatError(`Command *${command}* tidak ditemukan.\n\nGunakan .menu untuk melihat daftar command.`);
        await sock.sendMessage(sender, { text: errorText });
    }
}

module.exports = help; 