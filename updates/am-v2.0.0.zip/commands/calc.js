const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function calc(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        // Hapus command dari body
        const expression = body.replace('.calc', '').trim();

        if (!expression) {
            const usageMessage = formatMessage({
                type: "usage",
                title: "🧮 KALKULATOR",
                content: [
                    "CARA PENGGUNAAN:",
                    ".calc <operasi>",
                    "",
                    "OPERASI YANG DIDUKUNG:",
                    "• Penjumlahan: .calc 5 + 3",
                    "• Pengurangan: .calc 10 - 4",
                    "• Perkalian: .calc 6 * 7",
                    "• Pembagian: .calc 20 / 4",
                    "",
                    "CONTOH:",
                    ".calc 5 + 3 * 2",
                    ".calc (10 + 5) * 2"
                ],
                footer: "Bot by Amerie"
            });
            return sock.sendMessage(sender, { text: usageMessage });
        }

        try {
            // Evaluasi ekspresi matematika
            const result = eval(expression);

            // Cek apakah hasilnya valid
            if (typeof result !== 'number' || !isFinite(result)) {
                throw new Error('Hasil tidak valid');
            }

            // Format pesan hasil
            const message = formatMessage({
                type: "success",
                title: "🧮 HASIL KALKULASI",
                content: [
                    `Ekspresi: ${expression}`,
                    `Hasil: ${result}`,
                    "",
                    "Operasi yang dilakukan:",
                    ...getOperationDetails(expression)
                ],
                footer: "Bot by Amerie"
            });

            await sock.sendMessage(sender, { text: message });
        } catch (error) {
            const errorMessage = formatError('Ekspresi matematika tidak valid');
            await sock.sendMessage(sender, { text: errorMessage });
        }
    } catch (error) {
        console.error(clc.red('Error in calc:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat melakukan kalkulasi');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

// Helper function untuk mendapatkan detail operasi
function getOperationDetails(expression) {
    const details = [];
    
    // Cek operasi yang dilakukan
    if (expression.includes('+')) {
        details.push('• Penjumlahan (+)');
    }
    if (expression.includes('-')) {
        details.push('• Pengurangan (-)');
    }
    if (expression.includes('*')) {
        details.push('• Perkalian (*)');
    }
    if (expression.includes('/')) {
        details.push('• Pembagian (/)');
    }
    if (expression.includes('(') || expression.includes(')')) {
        details.push('• Penggunaan tanda kurung');
    }

    return details;
}

module.exports = calc; 