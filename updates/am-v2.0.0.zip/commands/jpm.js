const clc = require('cli-color');
const fs = require('fs');
const { updateJpmStatus, getJpmStatus, stopJpm } = require('../lib/jpmcontrol');
const { displayTime } = require('../lib/utils');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { isGroupBanned } = require('../lib/jpmBanManager');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Fungsi validasi JPM
async function validateAndStopJPM(sock, sender) {
  const status = getJpmStatus();
  if (status.isRunning) {
      console.log(clc.yellow(`[${displayTime()}] JPM masih berjalan, menghentikan terlebih dahulu...`));
      
      // Hentikan JPM yang sedang berjalan
      stopJpm();
      
      // Tunggu sebentar untuk memastikan JPM benar-benar berhenti
      await sleep(1000);
      
      // Kirim notifikasi ke user
      await sock.sendMessage(sender, {
          text: formatMessage({
              title: "PERINGATAN",
              content: [
                  "JPM yang sedang berjalan telah dihentikan.",
                  "Memulai JPM baru..."
              ]
          })
      });
      
      return true;
  }
  return false;
}

async function getallgc(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        // Format data grup dan filter grup yang di-banned
        return Object.values(groups)
            .filter(group => !isGroupBanned(group.id))
            .map(group => ({
                id: group.id,
                name: group.subject
            }));
    } catch (error) {
        console.error("Failed to fetch groups:", error);
        return false;
    }
}

async function sendToGroups(sock, groupList, text, imagePath, groupDelay) {
    let groupCount = 1;
    let skippedGroups = 0;
    let skippedGroupNames = [];
    
    for (const group of groupList) {
        // Cek status JPM setiap kali akan mengirim ke grup
        if (!getJpmStatus().isRunning) {
            console.log(clc.red(`[${displayTime()}] JPM dihentikan saat mengirim ke grup ${group.name}`));
            return false;
        }

        // Skip grup yang di-banned
        if (isGroupBanned(group.id)) {
            console.log(clc.yellow(`[${displayTime()}] Melewati grup ${group.name} karena di-banned`));
            skippedGroups++;
            skippedGroupNames.push(group.name);
            continue;
        }

        console.log(clc.green(`[${groupCount}] Mengirim Pesan ke grup: ${group.name}`));

        try {
            if (imagePath) {
                await sock.sendMessage(group.id, {
                    image: fs.readFileSync(imagePath),
                    caption: text
                });
            } else {
                await sock.sendMessage(group.id, { text: text });
            }
        } catch (error) {
            console.error(`Failed to send message to group ${group.name}:`, error);
        }

        // Cek status JPM setelah setiap pengiriman
        if (!getJpmStatus().isRunning) {
            console.log(clc.red(`[${displayTime()}] JPM dihentikan setelah mengirim ke grup ${group.name}`));
            return false;
        }

        await sleep(groupDelay);
        groupCount++;
    }

    // Update status dengan jumlah grup yang dilewati
    if (skippedGroups > 0) {
        console.log('\n' + clc.yellow('='.repeat(50)));
        console.log(clc.yellow(`[${displayTime()}] ⚠️  TOTAL ${skippedGroups} GRUP DILEWATI KARENA DI-BANNED:`));
        skippedGroupNames.forEach((name, index) => {
            console.log(clc.yellow(`[${displayTime()}] ${index + 1}. ${name}`));
        });
        console.log(clc.yellow('='.repeat(50)) + '\n');
    }

    return true;
}

async function jpm(sock, sender, messages, key, messageEvent) {
    const message = messageEvent.messages?.[0];
    let imagePath = null;

    // Validasi dan hentikan JPM yang sedang berjalan jika ada
    await validateAndStopJPM(sock, sender);

    const { isImageMessage, downloadAndSaveMedia } = require('../lib/utils');

    if (isImageMessage(messageEvent)) {
        try {
            const filename = `${sender}.jpeg`;
            const result = await downloadAndSaveMedia(sock, message, filename);

            if (result) {
                imagePath = `./tmp/${filename}`;
            }
        } catch (error) {
            console.error("An error occurred during image download and save:", error);
        }
    }

    const parts = messages.trim().split(' ');

    if (parts.length < 2) {
        const usageTemplate = formatMessage({
            type: "usage",
            title: "CARA PENGGUNAAN",
            content: [
                "COMMAND:",
                ".jpm pesan",
                "sertakan gambar jika ingin mengirim gambar",
                "CONTOH:",
                ".jpm hello"
            ],
            footer: "Bot by Amerie"
        });
        return sock.sendMessage(sender, { text: usageTemplate });
    }

    // Hapus command dari pesan
    const text = parts.slice(1).join(' ');

    if (!text) {
        return sock.sendMessage(sender, { react: { text: "❌", key } });
    }

    await sock.sendMessage(sender, { react: { text: "🪼", key } });

    const groupList = await getallgc(sock);

    if (!groupList) {
        return sock.sendMessage(sender, { react: { text: "🚫", key } });
    }

    const startTime = Date.now();
    let iteration = 1;

    // Menggunakan konfigurasi dari global.jpmConfig
    const { groupDelay, repeatDelay } = global.jpmConfig;

    // Update status JPM dengan pesan
    updateJpmStatus(true, startTime, iteration, groupList.length, 0, groupDelay, repeatDelay, text);

    // Kirim notifikasi awal
    const startMessage = formatMessage({
        type: "info",
        title: "JPM START",
        content: [
            `JPM SEDANG DIJALANKAN`,
            `TOTAL GRUP: ${groupList.length} GRUP`,
            `JEDA ANTAR GRUP: ${groupDelay / 1000} detik`,
            `JEDA PENGULANGAN: ${repeatDelay / (60 * 1000)} menit`
        ],
        footer: "Bot by Amerie"
    });
    await sock.sendMessage(sender, { text: startMessage });

    while (getJpmStatus().isRunning) {
        // Check if JPM has been stopped
        if (!getJpmStatus().isRunning) {
            console.log(clc.red(`[${displayTime()}] JPM dihentikan`));
            break;
        }

        // Kirim pesan ke semua grup
        const sendResult = await sendToGroups(sock, groupList, text, imagePath, groupDelay);
        
        // Jika pengiriman dihentikan di tengah jalan
        if (!sendResult) {
            break;
        }

        // Check lagi status JPM sebelum melanjutkan
        if (!getJpmStatus().isRunning) {
            break;
        }

        const completionMessage = formatMessage({
            type: "success",
            title: "SUKSES",
            content: [
                `Pengiriman ke ${iteration} selesai`,
                `Pengiriman ke berikutnya dalam ${repeatDelay / (60 * 1000)} menit`
            ],
            footer: "Bot by Amerie"
        });
        await sock.sendMessage(sender, { text: completionMessage });
        console.log(clc.green(`[${displayTime()}] Pengiriman ke ${iteration} selesai`));

        // Cek status JPM sebelum jeda
        if (!getJpmStatus().isRunning) {
            break;
        }

        // Tunggu sebelum pengulangan dengan pengecekan berkala
        const checkInterval = 1000; // Cek setiap 1 detik
        const totalChecks = Math.floor(repeatDelay / checkInterval);
        
        for (let i = 0; i < totalChecks; i++) {
            if (!getJpmStatus().isRunning) {
                break;
            }
            await sleep(checkInterval);
        }
        
        // Final check setelah jeda
        if (!getJpmStatus().isRunning) {
            break;
        }

        iteration++;
        // Update status iteration dengan pesan
        updateJpmStatus(true, startTime, iteration, groupList.length, 0, groupDelay, repeatDelay, text);
    }

    // Reset status JPM
    updateJpmStatus(false, null, 0, 0, 0, 0, 0, '');
    console.log(clc.green(`[${displayTime()}] JPM selesai/berhenti`));

    // Kirim notifikasi akhir
    const endMessage = formatMessage({
        type: "info",
        title: "JPM END",
        content: [
            `JPM telah selesai/berhenti`,
            `Total iterasi: ${iteration}`,
            `Total grup: ${groupList.length}`
        ],
        footer: "Bot by Amerie"
    });
    await sock.sendMessage(sender, { text: endMessage });

    return;
}

module.exports = jpm;