const { amerieApi, getCurrentBotVersion } = require('./amerie.obf');
const clc = require('cli-color');
const readline = require('readline');
const gradient = require('gradient-string');
const figlet = require('figlet');
const { deleteFolderRecursive, getStatus } = require('./lib/utils');
const { connectToWhatsApp } = require('./core/whatsapp');
global.jpmConfig = require('./config').jpmConfig;

// ─────────────────────────────────────────────────────────────
// 📌 Konstanta
const basePath = __dirname;
let pairingMethod = '';
const furinaGradient1 = gradient(['#023e8a', '#0077b6', '#0096c7', '#00b4d8', '#48cae4', '#90e0ef', '#ade8f4', '#caf0f8', '#ffffff']);
// ─────────────────────────────────────────────────────────────
// 🎨 Banner & Menu
console.clear();
console.log(furinaGradient1(
    figlet.textSync('AMERIE', {
      font: 'Standard',
      horizontalLayout: 'default',
      verticalLayout: 'default',
      width: 80,
      whitespaceBreak: true,
    }) + ' ' + getCurrentBotVersion()
  )
);
console.log(furinaGradient1('Dibuat dengan ❤️ oleh Amerie\n'));

// ─────────────────────────────────────────────────────────────
// 🔗 Koneksi WhatsApp
(async () => {
  await amerieApi();
  const status = getStatus(`${basePath}/sessions/`);
  if (status === 'connected') {
    console.log(clc.green('[✓] Sesi ditemukan. Menghubungkan...'));
    deleteFolderRecursive(basePath, 'tmp');
    connectToWhatsApp();
  } else {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    console.log(furinaGradient1('\n[?] Pilih metode koneksi (qr/pairing):'));

    // Hapus sesi lama
    deleteFolderRecursive(basePath, 'sessions');

    rl.question('', (method) => {
      if (method === 'qr' || method === 'pairing') {
        pairingMethod = method;

        if (method === 'pairing') {
          console.log(furinaGradient1('Masukkan nomor telepon (62xxxx): '));
          rl.question('Memproses nomor telepon: ', (number) => {
            connectToWhatsApp(number.trim(), pairingMethod);
            rl.close();
          });
        } else {
          connectToWhatsApp(null, pairingMethod);
          rl.close();
        }

      } else {
        console.log(clc.red('[!] Metode koneksi tidak valid. Gunakan "qr" atau "pairing".'));
        rl.close();
      }
    });
  }
})();
