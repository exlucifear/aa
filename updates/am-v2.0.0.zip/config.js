const fs = require('fs');

const jpmConfigPath = './data/jpm-config.json';
let jpmConfig = { groupDelay: 3000, repeatDelay: 60000 };

// Try load custom delay config
if (fs.existsSync(jpmConfigPath)) {
  try {
    jpmConfig = JSON.parse(fs.readFileSync(jpmConfigPath));
  } catch (err) {
    console.error("Gagal memuat jpm-config.json, menggunakan default:", err);
  }
}

module.exports = {
    numberAllowed: ['6289xxxx'],  // contoh nomor WA yang diizinkan
    sessionFolder: './sessions',
    prefix: '.',
    jpmConfig,
    tmpFolder: './tmp',
    //botVersion: '2.0.0',
  };
  