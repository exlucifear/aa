# Amerie JPM Bot

Bot WhatsApp otomatis untuk jasa share/jpm, dengan fitur update otomatis, verifikasi keaslian script, dan command handler modular.

---

## Fitur Utama

- **Update Otomatis:** Bot akan memeriksa keaslian script dan update otomatis dari server jika ada versi baru.
- **Restart Otomatis:** Setelah update, bot akan restart sendiri (pastikan dijalankan dengan process manager seperti PM2/forever).
- **Command Modular:** Mudah menambah/mengedit command di folder `commands/`.
- **Konfigurasi Mudah:** Semua pengaturan ada di file `config.js`/`config.example`.
- **Verifikasi Versi:** Hanya update jika versi server lebih baru.
- **Support Multi-Session:** Mendukung multi sesi WhatsApp.

---

## Instalasi

1. **Clone repo & install dependencies**
   ```bash
   git clone <repo-url>
   cd <repo-folder>
   npm install
   ```

2. **Salin konfigurasi**
   ```bash
   cp config.example config.js
   ```
   Edit `config.js` sesuai kebutuhan (nomor yang diizinkan, prefix, dsb).

3. **Jalankan bot**
   ```bash
   npm start
   ```
   Atau gunakan process manager:
   ```bash
   pm2 start npm --name amerie-jpm -- start
   ```

---

## Konfigurasi

Contoh isi `config.js`:
```js
module.exports = {
    numberAllowed: ['6289xxxx'],  // Nomor WA yang diizinkan
    sessionFolder: './sessions',
    prefix: '.',
    jpmConfig: { groupDelay: 3000, repeatDelay: 60000 },
    tmpFolder: './tmp',
};
```

---

## Struktur Folder

- `index.js` — Entry point utama, menampilkan banner, cek update, dan koneksi WhatsApp.
- `amerie.js` — Logic update otomatis & verifikasi versi.
- `core/whatsapp.js` — Koneksi dan handler WhatsApp.
- `lib/` — Utility/helper (ban manager, command handler, dsb).
- `commands/` — Kumpulan command bot (menu, help, jpm, dsb).
- `data/` — Data runtime (misal: config jpm, dsb).
- `config.js` — Konfigurasi utama bot.

---

## Fitur Command

- `.menu` — Menampilkan menu utama
- `.help` — Bantuan command
- `.jpm` — Command utama jpm/share
- `.jpmstatus`, `.jpmban`, `.jpmunban`, dsb — Manajemen jpm & ban
- **dan banyak lagi** (lihat folder `commands/`)

---

## Update Otomatis

- Bot akan memeriksa keaslian script ke server update setiap kali dijalankan.
- Jika ada versi baru, bot akan:
  1. Download update (ZIP)
  2. Ekstrak & replace file
  3. Jalankan `npm install`
  4. Restart otomatis

> **Pastikan bot dijalankan dengan process manager agar restart otomatis berjalan!**

---

## Kontribusi

Pull request & issue sangat diterima!

---

## Lisensi

MIT

---

## Author

- [amerie](mailto:your-email@example.com)
