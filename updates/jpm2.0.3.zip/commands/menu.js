const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function menu(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        const commands = {
            'JPM Commands': [
                { command: '.jpm [pesan]', description: 'Kirim pesan ke semua grup' },
                { command: '.jpmtarget [target]', description: 'Set target jumlah member baru' },
                { command: '.jpmreset', description: 'Reset data JPM' },
                { command: '.jpmstop', description: 'Hentikan JPM yang sedang berjalan' },
                { command: '.jpmstatus', description: 'Cek status JPM' },
                { command: '.jpmban [id]', description: 'Ban grup dari JPM' },
                { command: '.jpmunban [id]', description: 'Unban grup dari JPM' },
                { command: '.jpmconfig', description: 'Cek konfigurasi JPM' },
                { command: '.listban', description: 'Lihat daftar grup yang diban' },
                { command: '.delay [menit]', description: 'Set delay antar pesan' }
            ],
            'Group Commands': [
                { command: '.jumlah', description: 'Cek jumlah member grup' },
                { command: '.jumlahreset', description: 'Reset data jumlah member' },
                { command: '.listgc', description: 'Lihat daftar grup' },
                { command: '.idgc', description: 'Lihat ID grup' },
                { command: '.pushkontak', description: 'Push kontak ke semua grup' }
            ],
            'Info Commands': [
                { command: '.menu', description: 'Tampilkan menu ini' },
                { command: '.info', description: 'Cek informasi bot' },
                { command: '.help [cmd]', description: 'Tampilkan bantuan command' },
                { command: '.calc', description: 'Kalkulator' }

            ]
        };

        const message = formatMessage('𝑴𝑬𝑵𝑼', 
            Object.entries(commands).map(([category, items]) => 
                `*💭⊱ ׅ${category}*\n` +
                items.map(item => 
                    `*${item.command}*\n` +
                    `╰➤ ${item.description}`
                ).join('\n')
            ).join('\n\n')
        );
        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in menu:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat menampilkan menu');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = menu; 