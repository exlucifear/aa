const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { getJpmStatus } = require('../lib/jpmcontrol');
const { getAllGroupData } = require('../lib/jumlah');
const { getBannedGroups } = require('../lib/jpmBanManager');

async function jpmconfig(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        // Ambil status dan konfigurasi JPM
        const jpmStatus = getJpmStatus();
        const groupData = getAllGroupData();
        const bannedGroups = getBannedGroups();
        
        // Hitung statistik
        const totalGroups = Object.keys(groupData).length;
        const totalBannedGroups = bannedGroups.length;
        const totalMembers = Object.values(groupData).reduce((sum, data) => sum + (data.currentCount || 0), 0);
        const totalNewMembers = Object.values(groupData).reduce((sum, data) => {
            const newMembers = (data.currentCount || 0) - (data.initialCount || 0);
            return sum + (newMembers > 0 ? newMembers : 0);
        }, 0);

        // Format pesan
        const message = formatMessage({
            type: "info",
            title: "⚙️ JPM CONFIGURATION",
            content: [
                "📱 JPM STATUS",
                `• Status: ${jpmStatus.isRunning ? '🟢 Running' : '🔴 Stopped'}`,
                `• Runtime: ${formatRunTime(Math.floor(jpmStatus.runTime / 1000))}`,
                `• Iteration: ${jpmStatus.iteration || 0}`,
                "",
                "⚙️ DELAY SETTINGS",
                `• Group Delay: ${jpmStatus.groupDelay || 0}ms`,
                `• Repeat Delay: ${jpmStatus.repeatDelay || 0}ms`,
                "",
                "🎯 TARGET SETTINGS",
                `• Target Group: ${global.jpmConfig?.groupId || 'Belum diset'}`,
                `• Target Member: ${global.jpmConfig?.stopOnTarget || 'Belum diset'}`,
                "",
                "📊 GROUP STATISTICS",
                `• Total Groups: ${totalGroups}`,
                `• Banned Groups: ${totalBannedGroups}`,
                `• Total Members: ${totalMembers}`,
                `• New Members: ${totalNewMembers}`,
                "",
                "📝 COMMAND USAGE",
                "• .jpm <pesan> - Mulai JPM",
                "• .jpmstop - Hentikan JPM",
                "• .jpmreset - Reset semua data JPM",
                "• .jpmban <id> - Ban grup",
                "• .jpmunban <id> - Unban grup",
                "• .jpmtarget <id> <target> - Set target member",
                "• .jumlah - Cek jumlah member",
                "• .listjumlah - Lihat semua data jumlah",
                "",
                "⚠️ NOTES",
                "• JPM akan berhenti otomatis jika target tercapai",
                "• Grup yang di-ban tidak akan menerima pesan JPM",
                "• Delay dapat diatur untuk menghindari spam"
            ],
            footer: "Bot by Amerie"
        });

        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in jpmconfig:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil konfigurasi JPM');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

// Helper function untuk format runtime
function formatRunTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (secs > 0) parts.push(`${secs} detik`);

    return parts.join(' ');
}

module.exports = jpmconfig; 