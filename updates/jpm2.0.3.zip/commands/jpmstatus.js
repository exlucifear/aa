const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { getJpmStatus } = require('../lib/jpmcontrol');

function formatRunTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    const parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (remainingSeconds > 0 || parts.length === 0) parts.push(`${remainingSeconds} detik`);
    
    return parts.join(' ');
}

async function jpmstatus(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        const status = getJpmStatus();
        const statusMessage = {
            type: "info",
            title: "JPM STATUS",
            content: [
                `Status: ${status.isRunning ? 'BERJALAN' : 'TIDAK BERJALAN'}`,
                status.isRunning ? [
                    `Waktu Mulai: ${new Date(status.startTime).toLocaleString()}`,
                    `Iterasi: ${status.iteration}`,
                    `Total Grup: ${status.totalGroups}`,
                    `Waktu Berjalan: ${formatRunTime(Math.floor(status.runTime / 1000))}`,
                    `Jeda Antar Grup: ${status.groupDelay / 1000} detik`,
                    `Jeda Pengulangan: ${status.repeatDelay / (60 * 1000)} menit`,
                    `Pesan: ${status.currentMessage}`
                ].join('\n') : 'Tidak ada JPM yang berjalan'
            ],
            footer: "Bot by Amerie"
        };
        await sock.sendMessage(sender, { text: formatMessage(statusMessage) });
    } catch (error) {
        console.error(clc.red('Error in jpmstatus:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengambil status JPM');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = jpmstatus; 