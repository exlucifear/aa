const { getNewMemberCount, getAllGroupData, initializeGroup, resetGroupData, checkTarget } = require('../lib/jumlah.js');
const { addBannedGroup, isGroupBanned } = require('../lib/jpmBanManager.js');
const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat.js');
const { stopJpm } = require('../lib/jpmcontrol.js');

// Konstanta untuk validasi
const MAX_TARGET = 1000; // Maksimum target member baru
const MIN_TARGET = 1;    // Minimum target member baru

async function jpmtarget(sock, senderJid, body, messageKey, messageEvent, args, senderNumber) {
    try {
        let targetGroupId;
        let target;

        // Check if command is used in private chat or group
        if (senderJid.endsWith('@s.whatsapp.net')) {
            // Private chat - need group ID and target as arguments
            if (args.length < 2) {
                const errorMessage = formatError('ID grup dan target harus diisi saat menggunakan command di private chat');
                return sock.sendMessage(senderJid, { text: errorMessage });
            }
            targetGroupId = args[0];
            target = parseInt(args[1]);
            if (!targetGroupId.endsWith('@g.us')) {
                const errorMessage = formatError('ID grup tidak valid');
                return sock.sendMessage(senderJid, { text: errorMessage });
            }
        } else {
            // Group chat - use current group ID and target from args
            targetGroupId = senderJid;
            if (!args.length) {
                const errorMessage = formatError('Target harus diisi');
                return sock.sendMessage(senderJid, { text: errorMessage });
            }
            target = parseInt(args[0]);
        }

        if (isNaN(target) || target < 1) {
            const errorMessage = formatError('Target harus berupa angka positif');
            return sock.sendMessage(senderJid, { text: errorMessage });
        }

        // Get group participants
        const groupInfo = await sock.groupMetadata(targetGroupId);
        const participants = groupInfo.participants.map(p => p.id);

        // Check if group exists in memberData
        const memberData = getAllGroupData();
        if (memberData[targetGroupId]) {
            // Reset group data if exists
            resetGroupData(targetGroupId);
        }

        // Cek dan tambahkan ke daftar ban
        if (isGroupBanned(targetGroupId)) {
            console.log(clc.yellow(`[BAN] ID grup ${targetGroupId} telah ada di daftar ban`));
        } else {
            addBannedGroup(targetGroupId);
            console.log(clc.green(`[BAN] ID grup ${targetGroupId} berhasil ditambahkan ke daftar ban`));
        }

        // Initialize new group data with target
        const result = await initializeGroup(targetGroupId, participants, target);
        if (!result.success) {
            const errorMessage = formatError(result.error || 'Gagal menginisialisasi grup');
            return sock.sendMessage(senderJid, { text: errorMessage });
        }

        console.log(clc.green(`[TARGET] Target berhasil diatur ke ${target} member untuk grup ${targetGroupId}`));

        const message = formatMessage({
            type: "success",
            title: "JPM TARGET",
            content: [
                `Target berhasil diset: ${target} member`,
                `Jumlah member saat ini: ${result.currentMembers}`,
                `Member baru: ${result.newMembers}`,
                `Grup telah ditambahkan ke daftar ban`
            ],
            footer: "Bot by Amerie"
        });
        await sock.sendMessage(senderJid, { text: message });

    } catch (error) {
        console.error(clc.red('Error in jpmtarget:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengatur target');
        await sock.sendMessage(senderJid, { text: errorMessage });
    }
}

module.exports = jpmtarget;
