const { resetGroupData, resetAllGroupData } = require('../lib/jumlah.js');
const fs = require('fs');
const path = require('path');
const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function jumlahreset(sock, sender, body, key, messageEvent, args, senderNumber) {
  try {
    // Check if command is used in private chat
    if (sender.endsWith('@s.whatsapp.net')) {
      // Private chat without arguments - reset all data
      if (!args.length) {
        const result = await resetAllGroupData();
        if (!result.success) {
          const errorMessage = formatError(result.error || 'Gagal mereset semua data grup');
          return sock.sendMessage(sender, { text: errorMessage });
        }
        const message = formatMessage('𝑱𝑼𝑴𝑳𝑨𝑯 𝑹𝑬𝑺𝑬𝑻', 
          `Semua data grup berhasil direset\n` +
          `Total grup yang direset: ${result.totalGroups}`
        );
        return sock.sendMessage(sender, { text: message });
      }

      // Private chat with group ID argument
      const targetGroupId = args[0];
      if (!targetGroupId.endsWith('@g.us')) {
        const errorMessage = formatError('ID grup tidak valid');
        return sock.sendMessage(sender, { text: errorMessage });
      }

      const result = await resetGroupData(targetGroupId);
      if (!result.success) {
        const errorMessage = formatError(result.error || 'Gagal mereset data grup');
        return sock.sendMessage(sender, { text: errorMessage });
      }

      const message = formatMessage('𝑱𝑼𝑴𝑳𝑨𝑯 𝑹𝑬𝑺𝑬𝑻', 
        `Data grup berhasil direset\n` +
        `ID Grup: ${targetGroupId}\n` +
        `Jumlah member saat ini: ${result.currentMembers}`
      );
      return sock.sendMessage(sender, { text: message });
    } else {
      // Group chat - reset current group
      const result = await resetGroupData(sender);
      if (!result.success) {
        const errorMessage = formatError(result.error || 'Gagal mereset data grup');
        return sock.sendMessage(sender, { text: errorMessage });
      }

      const message = formatMessage('𝑱𝑼𝑴𝑳𝑨𝑯 𝑹𝑬𝑺𝑬𝑻', 
        `Data grup berhasil direset\n` +
        `Jumlah member saat ini: ${result.currentMembers}`
      );
      return sock.sendMessage(sender, { text: message });
    }
  } catch (error) {
    console.error(clc.red('Error in jumlahreset:'), error);
    const errorMessage = formatError('Terjadi kesalahan saat mereset data grup');
    await sock.sendMessage(sender, { text: errorMessage });
  }
}

module.exports = jumlahreset;
