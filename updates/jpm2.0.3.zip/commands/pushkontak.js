const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function pushkontak(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        if (!sender.endsWith('@g.us')) {
            const errorMessage = formatError('Command ini hanya bisa digunakan di grup');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        const metadata = await sock.groupMetadata(sender);
        const participants = metadata.participants;
        
        if (participants.length === 0) {
            const errorMessage = formatError('Tidak ada kontak dalam grup');
            return sock.sendMessage(sender, { text: errorMessage });
        }

        const message = formatMessage('𝑷𝑼𝑺𝑯 𝑲𝑶𝑵𝑻𝑨𝑲', 
            `Jumlah kontak: ${participants.length}\n` +
            `Status: Mengirim pesan ke semua kontak...`
        );
        await sock.sendMessage(sender, { text: message });

        let successCount = 0;
        let failCount = 0;

        for (const participant of participants) {
            try {
                await sock.sendMessage(participant.id, { 
                    text: `Halo! Saya dari grup ${metadata.subject}`
                });
                successCount++;
            } catch (error) {
                failCount++;
                console.error(clc.red(`Error sending to ${participant.id}:`), error);
            }
        }

        const resultMessage = formatMessage('𝑷𝑼𝑺𝑯 𝑲𝑶𝑵𝑻𝑨𝑲', 
            `Pengiriman selesai!\n` +
            `Berhasil: ${successCount}\n` +
            `Gagal: ${failCount}`
        );
        await sock.sendMessage(sender, { text: resultMessage });
    } catch (error) {
        console.error(clc.red('Error in pushkontak:'), error);
        const errorMessage = formatError('Terjadi kesalahan saat mengirim pesan ke kontak');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = pushkontak;