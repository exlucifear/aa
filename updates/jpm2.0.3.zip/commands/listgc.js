const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');

async function listgc(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        const groupList = Object.values(groups);

        if (!groupList.length) {
            const message = formatMessage('𝑳𝑰𝑺𝑻 𝑮𝑹𝑼𝑷', 'Tidak ada grup yang tersedia');
            return sock.sendMessage(sender, { text: message });
        }

        let listText = '';
        for (const group of groupList) {
            const groupName = group.subject || 'Tanpa Nama';
            const memberCount = group.participants.length;
            listText += `• ${groupName}\n  ID: ${group.id}\n  Member: ${memberCount}\n\n`;
        }

        const message = formatMessage('𝑳𝑰𝑺𝑻 𝑮𝑹𝑼𝑷', listText);
        await sock.sendMessage(sender, { text: message });
    } catch (error) {
        console.error(clc.red('Error in listgc:'), error);
        const errorMessage = formatError('Gagal mengambil daftar grup');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = listgc;