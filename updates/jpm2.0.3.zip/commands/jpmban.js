const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { addBannedGroup, isGroupBanned } = require('../lib/jpmBanManager');

async function jpmban(sock, senderJid, body, messageKey, messageEvent, args, senderNumber) {
    try {
        let targetGroupId;

        // Check if command is used in private chat or group
        if (senderJid.endsWith('@s.whatsapp.net')) {
            // Private chat - need group ID as argument
            if (!args.length) {
                const errorMessage = formatError('ID grup harus diisi saat menggunakan command di private chat');
                return sock.sendMessage(senderJid, { text: errorMessage });
            }
            targetGroupId = args[0];
            if (!targetGroupId.endsWith('@g.us')) {
                const errorMessage = formatError('ID grup tidak valid');
                return sock.sendMessage(senderJid, { text: errorMessage });
            }
        } else {
            // Group chat - use current group ID
            targetGroupId = senderJid;
        }

        // Add group to ban list using jpmBanManager
        const result = addBannedGroup(targetGroupId);
        
        if (result) {
            console.log(clc.green(`[BAN] ID grup ${targetGroupId} berhasil ditambahkan ke daftar ban`));
            const message = formatMessage('𝑱𝑷𝑴 𝑩𝑨𝑵', `Grup berhasil ditambahkan ke daftar ban`);
            await sock.sendMessage(senderJid, { text: message });
        } else {
            console.log(clc.yellow(`[BAN] ID grup ${targetGroupId} telah ada di daftar ban`));
            const message = formatMessage('𝑱𝑷𝑴 𝑩𝑨𝑵', 'Grup sudah ada dalam daftar ban');
            await sock.sendMessage(senderJid, { text: message });
        }
    } catch (error) {
        console.error(clc.red('Error in jpmban:'), error);
        const errorMessage = formatError('Gagal menambahkan grup ke daftar ban');
        await sock.sendMessage(senderJid, { text: errorMessage });
    }
}

module.exports = jpmban;