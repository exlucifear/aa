const clc = require('cli-color');
const { formatMessage, formatError } = require('../lib/messageFormat');
const { removeBannedGroup, isGroupBanned } = require('../lib/jpmBanManager');

async function jpmunban(sock, sender, body, key, messageEvent, args, senderNumber) {
    try {
        let targetGroupId;

        // Check if command is used in private chat or group
        if (sender.endsWith('@s.whatsapp.net')) {
            // Private chat - need group ID as argument
            if (!args.length) {
                const errorMessage = formatError('ID grup harus diisi saat menggunakan command di private chat');
                return sock.sendMessage(sender, { text: errorMessage });
            }
            targetGroupId = args[0];
            if (!targetGroupId.endsWith('@g.us')) {
                const errorMessage = formatError('ID grup tidak valid');
                return sock.sendMessage(sender, { text: errorMessage });
            }
        } else {
            // Group chat - use current group ID
            targetGroupId = sender;
        }

        // Remove group from ban list using jpmBanManager
        const result = removeBannedGroup(targetGroupId);
        
        if (result.removed) {
            console.log(clc.green(`[BAN] ID grup ${targetGroupId} berhasil dihapus dari daftar ban`));
            const message = formatMessage('𝑱𝑷𝑴 𝑼𝑵𝑩𝑨𝑵', `Grup berhasil dihapus dari daftar ban`);
            await sock.sendMessage(sender, { text: message });
        } else {
            console.log(clc.yellow(`[BAN] ID grup ${targetGroupId} tidak ditemukan di daftar ban`));
            const message = formatMessage('𝑱𝑷𝑴 𝑼𝑵𝑩𝑨𝑵', 'Grup tidak ada dalam daftar ban');
            await sock.sendMessage(sender, { text: message });
        }
    } catch (error) {
        console.error(clc.red('Error in jpmunban:'), error);
        const errorMessage = formatError('Gagal menghapus grup dari daftar ban');
        await sock.sendMessage(sender, { text: errorMessage });
    }
}

module.exports = jpmunban;
