const fs = require('fs');
const path = require('path');
const P = require('pino');
const qrcode = require('qrcode-terminal');
const clc = require('cli-color');
const gradient = require('gradient-string');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const CommandHandler = require('../lib/commandHandler');
const { numberAllowed, sessionFolder, botVersion, loggerConfig } = require('../config');
const { deleteFolderRecursive, ChangeStatus, handleCommand, displayTime } = require('../lib/utils.js');
const { updateGroupMembers, getGroupMembers, countNewMembers } = require('../lib/jumlah.js');
const { formatMessage } = require('../lib/messageFormat');
global.jpmConfig = require('../config').jpmConfig;


async function connectToWhatsApp(number = null, pairingMethod = 'qr') {
  try {
    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      version,
      auth: state,
      printQRInTerminal: false,
      logger: P({ level: 'fatal' }),
      markOnlineOnConnect: false,
      defaultQueryTimeoutMs: 0,
    });

    // Set global sock variable
    global.sock = sock;

    const commandHandler = new CommandHandler(sock);

    // Handle koneksi & login
    sock.ev.on('connection.update', update =>
      handleConnectionUpdate(sock, update, number, pairingMethod)
    );
      // Update credentials
    sock.ev.on('creds.update', saveCreds);
    // Pesan masuk
    sock.ev.on('messages.upsert', async (messageEvent) => {
      try {
        const message = messageEvent.messages?.[0];
        if (!message) return;
        // Cek apakah pesan adalah pesan grup
        const isGroup = Boolean(message.key?.participant);
        const senderJid = message.key.remoteJid || '';
        const senderNumber = isGroup
          ? (message.key.participant?.split('@')[0] || 'unknown')
          : (senderJid.split('@')[0] || 'unknown');
        const fromMe = message.key.fromMe || false;

        // Cek untuk private chat yang tidak diizinkan
        //if (!isGroup && !numberAllowed.includes(senderNumber) && !fromMe) {
          // Kirim pesan ke pengirim yang tidak diizinkan
          //await sock.sendMessage(senderJid, {
            //text: `⚠️ Maaf, nomor Anda tidak terdaftar untuk menggunakan bot ini.\n\nSilakan hubungi admin di kontak berikut:`
          //});
          
          // Kirim kontak admin
          //await sock.sendMessage(senderJid, {
            //contacts: {
              //displayName: "Admin Bot",
              //contacts: [{
                //displayName: "Admin Bot",
                //vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Admin Bot\nTEL;type=CELL;type=VOICE;waid=${numberAllowed[0]}:${numberAllowed[0]}\nEND:VCARD`
              //}]
            //}
          //});
          
          //console.log(`[${displayTime()}] Nomor ${senderNumber} tidak diizinkan chat bot.`);
          //return;
        //}

        // Cek untuk pesan dari grup yang nomornya tidak diizinkan
        //if (isGroup && !numberAllowed.includes(senderNumber) && !fromMe) {
          //return;
        //}

        let text = '';
        if (message.message?.conversation) text = message.message.conversation;
        else if (message.message?.extendedTextMessage?.text) text = message.message.extendedTextMessage.text;
        else if (message.message?.imageMessage?.caption) text = message.message.imageMessage.caption;

        if (text) {
          await commandHandler.handle(sock, senderJid, text.trim(), message.key, senderNumber, messageEvent);
        }
      } catch (error) {
        console.error('[ERROR] Error handling message:', error);
      }
    });

    // Hitung member baru
    sock.ev.on('group-participants.update', async (update) => {
      try {
        const groupId = update.id;
        const currentMembers = await getCurrentGroupMembers(sock, groupId);
        const groupMetadata = await sock.groupMetadata(groupId);
        const groupName = groupMetadata.subject;

        const oldMembers = getGroupMembers(groupId);
        const newMembersCount = countNewMembers(oldMembers, currentMembers);

        updateGroupMembers(groupId, currentMembers);

        if (newMembersCount > 0) {
          //console.log(`✅ Ada ${newMembersCount} member baru di grup ${groupName}`);
        }
      } catch (e) {
        console.error('[ERROR] Error update group members:', e);
      }
    });

  } catch (error) {
    console.error('❌ Gagal koneksi ke WhatsApp:', error);
  }
}

// Tangani status koneksi (open, close, qr, pairing)
async function handleConnectionUpdate(sock, update, number, pairingMethod) {
  const { connection, lastDisconnect, qr } = update;

  if (pairingMethod === 'qr' && qr) {
    qrcode.generate(qr, { small: true });
    console.log(gradient.rainbow('𐀔!-݈ ➣ Silakan scan QR Code'));
  } else if (connection && pairingMethod === 'pairing' && number && !sock.authState.creds.registered) {
    const phoneNumber = number.toString();
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    console.log(gradient.rainbow('𐀔!݇-݈ ➣ Meminta pairing code...'));
    await delay(3000);
    const code = await sock.requestPairingCode(phoneNumber.trim());
    const formattedCode = code.slice(0, 4) + '-' + code.slice(4);

    console.log(`${gradient.rainbow('𐀔!-݈ ➣ Kode Pairing:')} ${clc.yellow(formattedCode)}`);
    console.log(clc.yellow('[INFO] Silahkan masukan kode pairing di whatsapp'));
    console.log(clc.green('[INFO] Menunggu koneksi...'));
  }

  if (connection === 'close') {
    const shouldReconnect = (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut);
    ChangeStatus(sessionFolder, 'closed');

    if (shouldReconnect) {
      console.log(clc.yellow('[INFO] Menyambungkan ulang...'));
      connectToWhatsApp();
    } else {
      console.log(clc.red('[INFO] Koneksi ditutup permanen.'));
    }
  } else if (connection === 'open') {
    console.log(clc.green('[INFO] Bot berhasil terhubung ke WhatsApp!'));
    ChangeStatus(sessionFolder, 'connected');

    for (const no of numberAllowed) {
      try {
        const message = formatMessage('𝑩𝑶𝑻 𝑨𝑪𝑻𝑰𝑽𝑬', `✅ Bot sudah aktif\n📦 Versi: ${botVersion}\n🕰️ Waktu: ${new Date().toLocaleString()}`);
        const jid = `${no}@s.whatsapp.net`;
        await sock.sendMessage(jid, { text: message });
      } catch (error) {
        console.error(`Gagal kirim notifikasi ke ${no}:`, error.message);
      }
    }
  }
}

// Mendapatkan anggota grup saat ini
async function getCurrentGroupMembers(sock, groupId) {
  const groupMetadata = await sock.groupMetadata(groupId);
  return groupMetadata.participants.map(p => p.id);
}

module.exports = { connectToWhatsApp };
